---
name: Feature request
about: Suggest a new feature for OJS or OMP
title: ''
labels: ''
assignees: ''

---

**Describe the problem you would like to solve**
Example: Our editors need a way to [...]

**Describe the solution you'd like**
Tell us how you would like this solution to be solved.

**Who is asking for this feature?**
Tell us what kind of users are requesting this feature. Example: Journal Editors, Journal Administrators, Technical Support, Authors, Reviewers, etc.

**Additional information**
Add any other information or screenshots about the feature request here.

# Statistikker
Se statistik for artikler, der er blevet publiceret i dit tidsskrift, og filtrer efter datointerval og sektion. For mere detaljerede eller tilpassede visninger af statik, se rapportgeneratoren.

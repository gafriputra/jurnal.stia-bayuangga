# Indsendelsestrinnet

1. Introduktion
1. [Redaktionelle valgmuligheder](submission#editorial-actions)

Her vurderer redaktøren de indsendte filer og beslutter, om de skal sendes videre til bedømmelse.

Redaktøren kan udvælge en medredaktør ved at klikke på linket ’Tilføj’ i deltagerfeltet i højremenuen, eller starte en drøftelse med forfatteren for at diskutere eventuelle spørgsmål i feltet ’Drøftelser forud for bedømmelse’. 

## <a name="editorial-actions"></a>Redaktionelle valgmuligheder

### Send til bedømmelse

Videresend indsendelsen til [bedømmelsestrinnet](review), hvor det vil blive peer reviewet.

### Send til manuskriptredigering

Fremsend indsendelsen til [manuskriptredigeringstrinnet](copyediting), hvis du vil springe bedømmelsesprocessen over.

### Afvis indsendelse

Fjern og arkivér indsendelsen


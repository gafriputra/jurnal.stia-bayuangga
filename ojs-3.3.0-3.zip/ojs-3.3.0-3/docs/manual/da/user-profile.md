# Brugerprofil

Dette afsnit omhandler brugerprofiler inklusiv registrering, indlogning og rettelsesprocedurer.

Efter du er logget ind, kan du konfigurere din brugerprofil og meddelelsesoplysninger. Din profil findes via linket øverst til højre på siden \(ses først når du er logget ind\).

Du kan opdatere dit navn, kontaktoplysninger og adgangskode samt tilrette din brugerprofil og bestemme hvilken slags oplysninger, du ønsker at modtage.

Hvis du er indskrevet som bedømmer, kan du indsætte dine bedømmelsesinteresser under fanebladet ’Roller’.


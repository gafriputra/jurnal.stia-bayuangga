# Profil d’utilisateur-trice

Ce chapitre couvre les profils d’utilisateurs et utilisatrices, notamment l’inscription, la connexion et les modifications.

Une fois connecté-e, vous pouvez configurer votre profil d’utilisateur-trice et vos paramètres de notifications. Pour voir votre profil, cliquez sur votre nom d’utilisateur-trice en haut à droite du navigateur une fois identifié-e.

Vous pouvez mettre à jour votre nom, vos coordonnées et votre mot de passe. Vous pouvez aussi gérer votre profil public et configurer le type de notification que vous souhaiteriez recevoir. 

Une fois inscrit en tant qu'**évaluateur ou évaluatrice** sur ce site, vous pouvez préciser vos intérêts d'évaluation dans l’onglet «&nbsp;Rôles&nbsp;».

#Tâches

Le menu « Tâches » vous offre un accès rapide aux mises à jour et aux tâches en attente dans le flux des travaux.

Vous pouvez cliquer sur le lien « Tâches » en haut de page pour visualiser ou supprimer toute tâche en attente.

Pour plus d'informations, veuillez consulter [Learning OJS 3: Tasks](https://docs.pkp.sfu.ca/learning-ojs/en/editorial-workflow#tasks) (en anglais).

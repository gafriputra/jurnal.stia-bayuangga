# Statistcs
View statistics for articles published in your journal and filter by date range and section. For more detailed or cusotmized displays of statics, see the Report Generator.

# Perfil de usuario/a

Este capítulo trata sobre los perfiles de usuario, incluyendo el registro, el inicio de sesión y la realización de cambios.

Una vez iniciada la sesión podrá configurar su perfil de usuario/a y los ajustes de notificación. Para ver su perfil diríjase al enlace que muestra su nombre de usuario en la parte superior derecha del sitio web.

Puede modificar su nombre, sus detalles de contacto y su contraseña, así como gestionar su perfil público y configurar qué tipo de notificaciones desea recibir.

Si se ha registrado como **Revisor** podrá introducir sus intereses de revisión en la pestaña Roles.

# Tareas

El menú Tareas proporciona un acceso rápido a actualizaciones y responsabilidades pendientes del flujo de trabajo editorial.

Puede hacer clic en el enlace Tareas desde el menú principal de navegación para ver las tareas pendientes, así como eliminarlas cuando ya no sean útiles.

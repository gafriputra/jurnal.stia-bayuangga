# Tarefas

As Tarefas fornecem acesso rápido às atualizações e às responsabilidades em atraso dentro do processo editorial.

Ao clicar no link das Tarefas no menu de navegação visualiza qualquer tarefa pendente. Pode eliminar as Tarefas quando deixarem de ser necessárias.
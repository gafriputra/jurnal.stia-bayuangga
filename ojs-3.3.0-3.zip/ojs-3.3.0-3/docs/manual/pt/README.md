#Guia do Utilizador do OJS 3.0 

Este guia irá ajudá-lo a publicar revistas e volumes com o Open Journal Systems.

Fornece uma visão geral de cada etapa do processo editorial desde a submissão até à produção. Fornece ainda informação adicional de algumas opções de configuração.

Quando vê links de **Ajuda** dentro da aplicação, irão abrir um painel de ajuda com informação útil para essa secção.

Uma visão mais detalhada deste software está disponível em [Learning OJS 3.0](https://www.gitbook.com/book/pkp/ojs3/details).

--

Direitos de autor: Simon Fraser University detem os direitos de autor para o trabalho produzido pelo Public Knowledge Project e tem a sua documentação sobre a  [Lincença Creative Commons Atribuição 4.0 International License](http://creativecommons.org/licenses/by/4.0/).

[![](https://i.creativecommons.org/l/by/4.0/88x31.png "Creative Commons Attribution 4.0 International")](http://creativecommons.org/licenses/by/4.0/)




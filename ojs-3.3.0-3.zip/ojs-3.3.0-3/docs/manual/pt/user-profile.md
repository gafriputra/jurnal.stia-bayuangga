# Perfil de Utilizador

Este capítulo é dedicado aos perfis de utilizador, incluindo o registo, entrada e alterações.

Quando entra no sistema, pode configurar o seu Perfil de Utilizador e definições de notificação. Para visualizar o seu perfil, encontre o link com o seu nome de utilizador no canto superior direito do site quando está na sua conta.

Pode alterar o seu nome, detalhes de contacto e password, bem como gerir que tipo de notificações deseja receber.

Se tiver o papel de **Revisor** associado para este site, pode inserir os seus Interesses de Revisão no separador Papéis.